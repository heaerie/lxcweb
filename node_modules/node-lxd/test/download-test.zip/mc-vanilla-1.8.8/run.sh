cd $crateDir
java -jar "$crateJar"